<?php

/**

 */
/*
Plugin Name: example-plugin
Plugin URI: http://wordpress.org/plugins/hello-dolly/
Description:This is my first of plugin developing.
Author: Kasun Weerasinghe.
Version: 1.7.2
Author URI: https://www.linkedin.com/in/kasun-weerasinghe-264998229/
*/



//Add bar after the opening body
add_action('wp_body_open', 'tb_head');

function get_user_or_websitename()
{
    if( !is_user_logged_in() )
    {
        return 'to ' . get_bloginfo('name');
    }
    else
    {
        $current_user = wp_get_current_user();
        return $current_user -> user_login;
    }
}

function tb_head()
{
    echo '<h3 class="tb">Welcome ' .get_bloginfo('name') .  '</h3>';
}

//Add CSS to the top bar
add_action('wp_print_styles', 'tb_css');

function tb_css()
{
    echo '
        <style>
        h3.tb {color: #fff; margin: 0; padding: 30px; text-align: center; background: orange}
        </style>
    ';
}